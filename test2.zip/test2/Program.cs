﻿using System;
using System.IO;
using System.Net;
using System.Text;
using Newtonsoft.Json.Linq;
using System.Globalization;
using System.Text.RegularExpressions;

namespace test2
{
    class Program
    {
        static void Main(string[] args)
        {
            string uri = @"https://jsonplaceholder.typicode.com/";
            string fullUri = null;
            
            //create full URI for the api call
            fullUri = userUri(uri);

            //create the request for fullURI
            string users = request(fullUri);

            //parse the string in Json structure
            var usersJson = JArray.Parse(users);

            //get count
            int responseLength = usersJson.Count;
            Console.WriteLine("total count = " + responseLength);

            //get user id for Samantha
            int userId = 0;
            string userName = null;
            for(int i=0; i<responseLength; i++)
            {
                userName = usersJson[i]["username"].ToString();
                if (userName == "Samantha")
                {
                    userId = (int)usersJson[i]["id"];
                    Console.WriteLine(userId);
                    break;
                }
            }


            //create full URI for the api call
            fullUri = postsUri(uri, userId);
            
            //create the request for fullURI
            string userPosts = request(fullUri);

            //parse the string in Json structure
            var postsJson = JArray.Parse(userPosts);
            //get count
            int postsCount = postsJson.Count;
            Console.WriteLine("Posts count for the user " + userName + " = " + responseLength);

            //get post ids
            int[] postIds = new int[postsCount];
            for(int j = 0; j<postsCount; j++)
            {
                postIds[j] = (int)postsJson[j]["id"];
                
                
                //create full URI for the api call
                fullUri = commentsUri(uri, postIds[j]);

                //create the request for fullURI
                string postComments = request(fullUri);

                //parse the string in Json structure
                var commentsJson = JArray.Parse(postComments);
                //get count
                int commentsCount = commentsJson.Count;
                Console.WriteLine("User: " + userName);
                Console.WriteLine("\tPost ID: " + postIds[j]);
                Console.WriteLine("\t\tComments Count: " + commentsCount);

                foreach(JObject comment in commentsJson)
                {
                    string commentEmail = comment["email"].ToString();
                    if (IsValidEmail(commentEmail))
                        Console.WriteLine("\t\t\tComment ID: #" + comment["id"] + " Email: " + comment["email"] +" - Valid");
                    else
                        Console.WriteLine("\t\t\tComment ID: #" + comment["id"] + " Email: " + comment["email"] + " - InValid");
                }
            }

            Console.ReadKey();

        }

        public static string userUri(string uri)
        {
            string userUri = uri + "users";
            return userUri;
        }

        public static string postsUri(string uri, int userId)
        {
            string userUri = uri + "posts?userId=" + userId;
            return userUri;
        }
        
        public static string commentsUri(string uri, int postId)
        {
            string userUri = uri + "comments?postId=" + postId;
            return userUri;
        }

        public static string request(string fullUri)
        {
            string requestId = null;
            string s = null;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(fullUri);
            request.Method = "GET";
            try
            {
                s = GetPayload(request, out requestId);
            }
            catch (WebException ex)
            {
                Console.WriteLine(ex.Message);
            }
            return s;
        }

        #region HTTP request
        public static string GetPayload(HttpWebRequest request, out string requestId, string payload = null)
        {
            string result = String.Empty;
            var response = SetRequestAndGetResponse(request, out requestId);
            if (response.StatusCode != HttpStatusCode.OK)
                throw new ApplicationException("Request wrong");
            var stream = response.GetResponseStream();
            StreamReader reader = new StreamReader(stream);
            result = reader.ReadToEnd();
            return result;
        }

        public static HttpWebResponse SetRequestAndGetResponse(HttpWebRequest request, out string requestId, string payload = null)
        {
            while (true)
            {
                //Add a guid to help with diagnostics
                requestId = Guid.NewGuid().ToString();
                //To authorize the operation call, you need an access token which is part of the Authorization header  
                //Set to false to be able to intercept redirects  

                HttpWebResponse response = request.GetResponse() as HttpWebResponse;

                // Requests to **Azure Data Catalog (ADC)** may return an HTTP 302 response to indicate  
                // redirection to a different endpoint. In response to a 302, the caller must re-issue  
                // the request to the URL specified by the Location response header.  
                
                return response;
                
            }
        }

        #endregion


        public static bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            try
            {
                // Normalize the domain
                email = Regex.Replace(email, @"(@)(.+)$", DomainMapper,
                                      RegexOptions.None, TimeSpan.FromMilliseconds(200));

                // Examines the domain part of the email and normalizes it.
                string DomainMapper(Match match)
                {
                    // Use IdnMapping class to convert Unicode domain names.
                    var idn = new IdnMapping();

                    // Pull out and process domain name (throws ArgumentException on invalid)
                    var domainName = idn.GetAscii(match.Groups[2].Value);

                    return match.Groups[1].Value + domainName;
                }
            }
            catch (RegexMatchTimeoutException e)
            {
                return false;
            }
            catch (ArgumentException e)
            {
                return false;
            }

            try
            {
                return Regex.IsMatch(email,
                    @"^(?("")("".+?(?<!\\)""@)|(([0-9a-z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-z])@))" +
                    @"(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-0-9a-z]*[0-9a-z]*\.)+[a-z0-9][\-a-z0-9]{0,22}[a-z0-9]))$",
                    RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250));
            }
            catch (RegexMatchTimeoutException)
            {
                return false;
            }
        }
    }
}
